package prog12_1;

public class IllegalTriangleException extends IllegalClosedCurveException {

	public IllegalTriangleException(String msg) {
		super(msg);
	}
		
}
