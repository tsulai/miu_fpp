package prog7_1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(Exponential.power(2,10));
	}

}
