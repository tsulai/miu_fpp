package prog5_1.multithreaded;

public class Main {

	public static void main(String[] args) {
		
		MySingleton sgt1 = MySingleton.getInstance();
		MySingleton sgt2 = MySingleton.getInstance();

	}

}
