package prog5_1.singlethreaded;

public class Main {

	public static void main(String[] args) {
		
		MySingleton sgt1 = MySingleton.getInstance();
		MySingleton sgt2 = MySingleton.getInstance();

	}

}
