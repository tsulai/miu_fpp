package midterm_practice.ooproblem;

public abstract class Figure {
 public abstract String getFigure();
}
