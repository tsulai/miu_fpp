package midterm_practice.ooproblem;

class VeeMaker extends Figure{
    String figure = "\\/";
    @Override
    public String getFigure() {
        return figure;
    }
}