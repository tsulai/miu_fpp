package midterm_practice.ooproblem;

public class FaceMaker extends Figure {
	String figure = ":)";
	@Override
	public String getFigure() {
		return figure;
		
	}
}
