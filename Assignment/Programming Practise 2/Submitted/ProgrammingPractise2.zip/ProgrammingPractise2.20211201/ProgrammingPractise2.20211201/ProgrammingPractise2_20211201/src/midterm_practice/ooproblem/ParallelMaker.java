package midterm_practice.ooproblem;

class ParallelMaker extends Figure {
    
    String figure = "||";
    @Override
    public String getFigure() {
        return figure;
    }
}