package midterm_practice.ooproblem;

class HatMaker extends Figure{
     String figure = "/\\";
    @Override
    public String getFigure() {
        return figure;
    }
}