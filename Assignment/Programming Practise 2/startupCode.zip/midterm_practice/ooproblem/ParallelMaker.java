package midterm_practice.ooproblem;

class ParallelMaker {
    
    String figure = "||";
    
    public String getFigure() {
        return figure;
    }
}