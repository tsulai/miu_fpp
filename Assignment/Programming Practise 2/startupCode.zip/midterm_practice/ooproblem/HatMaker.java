package midterm_practice.ooproblem;

class HatMaker {
     String figure = "/\\";
    
    public String getFigure() {
        return figure;
    }
}