package midterm_practice.ooproblem;

class VeeMaker {
    String figure = "\\/";
    
    public String getFigure() {
        return figure;
    }
}