package prog4_5;

abstract public class ClosedCurve {
	abstract double computeArea();

}
