package closedcurve.good;
/*This covers included for Assignment 4-4*/
public interface Polygon {
	
	public int getNumberOfSides();
	public double computePerimeter();


}
