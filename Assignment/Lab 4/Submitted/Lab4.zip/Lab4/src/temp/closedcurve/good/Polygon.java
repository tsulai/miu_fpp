package closedcurve.good;

public interface Polygon {
		
	public int getNumberOfSides();
	public double computePerimeter();


}
