package prog4_2_n_prog4_4;
/*This covers included for Assignment 4-4*/
public interface Polygon {
	
	public int getNumberOfSides();
	public double computePerimeter();


}
