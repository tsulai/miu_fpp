package prog4_2_n_prog4_4;

abstract public class ClosedCurve {
	abstract double computeArea();

}
