package prob2;

public interface BoardingTime {
	abstract double computeBoardingTime();
}
